import pyhdbcli
ResultRow = pyhdbcli.ResultRow
