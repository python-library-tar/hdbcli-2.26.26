import shutil
import os
import sys
import ctypes
import sysconfig

try:
    import logging
    import setuptools
    from setuptools import setup, Extension
    from setuptools.command.build_ext import build_ext as _build_ext
    from setuptools.command.install import install as _install
except ImportError:
    from distutils.errors import DistutilsPlatformError
    raise DistutilsPlatformError("hdbcli requires pip/setuptools")

from io import open

class build_ext(_build_ext):
    def _doesload(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        try:
            dll = ctypes.pydll.LoadLibrary(src)
            del dll
        except:
            logging.info('hdbcli: Test load of %s failed (library missing? wrong platform? wrong bitness?)' % self.get_ext_filename(ext.name))
            return False
        logging.info('hdbcli: Test load of %s was successful' % self.get_ext_filename(ext.name))
        return True

    def _copy_ext(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        tgt = self.get_ext_fullpath(ext.name)
        if os.name == 'nt' and tgt.endswith('.abi3.pyd'):
            tgt = tgt[:-len('.abi3.pyd')]
            tgt += '.pyd'
        logging.info('hdbcli: Installing %s as %s' % (os.path.basename(src), os.path.basename(tgt)))
        shutil.copyfile(src, tgt)

    def _have_compiled_ext(self, ext):
        src = os.path.join('ext', self.get_ext_filename(ext.name))
        logging.info('hdbcli: Searching for %s' % os.path.basename(src))
        if src.endswith('pyhdbcli.pyd') and os.name == 'nt':
            logging.info('hdbcli: Skipping search for %s' % os.path.basename(src))
            return False
        if os.path.isfile(src):
            logging.info('hdbcli: %s found' % os.path.basename(src))
            return True
        else:
            logging.info('hdbcli: %s not found' % os.path.basename(src))
            return False

    def get_ext_filename(self, fullname):
        fullname = super(build_ext, self).get_ext_filename(fullname)
        if '.abi3' not in fullname:
            so_ext = sysconfig.get_config_var('EXT_SUFFIX')
            if len(so_ext) >= len(fullname):
                fullname = 'pyhdbcli.abi3' + (sysconfig.get_config_var('SHLIB_SUFFIX') if not os.name == 'nt' else '.pyd')
            else:
                fullname = fullname[:-len(so_ext)]
                fullname += '.abi3' + (sysconfig.get_config_var('SHLIB_SUFFIX') if not os.name == 'nt' else '.pyd')
        return fullname

    def build_extension(self, ext):
        if sys.version_info[0] == 2:
            raise PlatformError("hdbcli does not support Python 2")
        elif sys.maxsize < 2**32 and not os.name == 'nt':
            raise PlatformError("hdbcli does not support 32-bit Python")
        elif sys.version_info[0] == 3 and sys.version_info[1] < 8:
            raise PlatformError("hdbcli requires Python 3.8 or greater")

        ext.py_limited_api = True
        if self._have_compiled_ext(ext) and self._doesload(ext):
            self._copy_ext(ext)
        else:
            raise PlatformError("This hdbcli installer is not compatible with your Python interpreter")

try:
    with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'README'), encoding='utf-8') as f:
        long_description = f.read()
except OSError:
    long_description = 'See README'

setupargs = dict(
    name = 'hdbcli',
    version = '2.26.26',
    description = 'SAP HANA Python Client',
    long_description = long_description,
    long_description_content_type = 'text/x-rst',
    url = 'https://www.sap.com/',
    author = 'SAP SE',
    license = 'SAP DEVELOPER LICENSE AGREEMENT',
    project_urls = { 'Documentation': 'https://help.sap.com/viewer/f1b440ded6144a54ada97ff95dac7adf/latest/en-US/f3b8fabf34324302b123297cdbe710f0.html',
                   },
    classifiers=[ 'Development Status :: 5 - Production/Stable',
                  'Intended Audience :: Developers',
                  'Intended Audience :: End Users/Desktop',
                  'Intended Audience :: Financial and Insurance Industry',
                  'Intended Audience :: Healthcare Industry',
                  'Intended Audience :: Information Technology',
                  'Intended Audience :: Legal Industry',
                  'Intended Audience :: Manufacturing',
                  'Intended Audience :: Science/Research',
                  'License :: Other/Proprietary License',
                  'Operating System :: MacOS',
                  'Operating System :: MacOS :: MacOS X',
                  'Operating System :: Microsoft :: Windows :: Windows 11',
                  'Operating System :: Microsoft :: Windows :: Windows 10',
                  'Operating System :: POSIX :: Linux',
                  'Programming Language :: Python',
                  'Programming Language :: Python :: 3',
                  'Programming Language :: Python :: 3.8',
                  'Programming Language :: Python :: 3.9',
                  'Programming Language :: Python :: 3.10',
                  'Programming Language :: Python :: 3.11',
                  'Programming Language :: Python :: 3.12',
                  'Programming Language :: Python :: 3.13',
                  'Topic :: Database',
                  'Topic :: Software Development :: Libraries :: Python Modules',
               ],
    keywords = 'SAP HANA client in-memory database SQL cloud business application intelligent enterprise AI artificial intelligence analytics experience',
    packages = ['hdbcli'],
    ext_modules = [Extension('pyhdbcli', [])],
    cmdclass = {'build_ext':build_ext}
)

setup(**setupargs)
